﻿'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Layout from '../../components/Layout';
import CameraBarcodeScanner from '../../components/CameraBarcodeScanner';
import { cancelDeferred, readPageCache, scheduleDeferred, writePageCache } from '../../lib/pageCache';
import { apiUrl } from '../../lib/api';
import { useIndustry } from '../../contexts/IndustryContext';
import DynamicFormField from '../../components/DynamicFormField';

import DynamicFormSection, { flattenSectionFields, formatMetaValue, validateSections } from '../../components/DynamicFormSection';
import { getInvBehavior, hasInventoryPanel, isBatchMode, isVariantMode, isSerialMode, isRecipeMode, getPrimaryPanelLabel } from '../../lib/inventoryBehavior';
import { queueStockAdjust } from '../../lib/offlineQueue';
import PageHeader from '../../components/ui/PageHeader';
import BatchInventoryPanel from '../../components/BatchInventoryPanel';
import VariantInventoryPanel from '../../components/VariantInventoryPanel';
import RecipePanel from '../../components/RecipePanel';
import SerialInventoryPanel from '../../components/SerialInventoryPanel';

/* ─── Constants & helpers (ALL UNCHANGED) ────────────────────────── */
const getToken = () => localStorage.getItem('token');
const HSN_GST_HINTS = { 84:18, 85:18, 30:12, 61:5, 62:5, 64:12, 90:18 };
const PRODUCTS_CACHE_KEY = 'products-page';
const normalizeBarcode = (v = '') => String(v).replace(/\s+/g, '').trim();
const historyTypeLabel = (t) => ({ purchase:'Purchase', sale:'Sale', manual_add:'Added', manual_remove:'Removed', adjustment:'Adjusted' }[t] || t);

/* ─── Shared classes ── */
const INP = 'h-11 w-full rounded-xl border-2 border-slate-200 bg-white px-4 text-[14px] text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-600 transition-all';
const SEL = 'h-11 w-full rounded-xl border-2 border-slate-200 bg-white px-4 text-[14px] text-slate-700 focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-600 transition-all';

/* ─── Stock status helpers ── */
function stockStatus(p) {
  if (p.quantity === 0) return { label: 'खत्म',    cls: 'bg-rose-100 text-rose-700 border-rose-200',     dot: 'bg-rose-500'   };
  if (p.is_low_stock)   return { label: `कम (${p.quantity})`, cls: 'bg-amber-100 text-amber-700 border-amber-200', dot: 'bg-amber-500' };
  return                       { label: 'उपलब्ध', cls: 'bg-emerald-100 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' };
}
function marginColor(m) {
  if (m == null) return 'text-slate-400';
  if (m >= 30)   return 'text-emerald-600';
  if (m >= 15)   return 'text-amber-600';
  return 'text-rose-600';
}

function parseProductCSV(text) {
  const lines  = text.trim().split(/\r?\n/);
  if (lines.length < 2) return [];
  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  return lines.slice(1).map(line => {
    const vals = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
    return Object.fromEntries(headers.map((h, i) => [h, vals[i] || '']));
  }).filter(r => r.name || r.Name);
}

/* ─── Modal backdrop ── */
function Backdrop({ children, onClose }) {
  return (
    <div
      className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-slate-900/40 backdrop-blur-sm p-0 sm:p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      {children}
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════
   MAIN PAGE
═══════════════════════════════════════════════════════════════════ */
export default function ProductsPage() {
  const router = useRouter();
  const { term, config } = useIndustry();

  /* ── Schema-derived constants ── */
  const pSchema    = config.productFormSchema || {};
  const trackQty   = pSchema.trackQuantity !== false;
  const showBarcode = pSchema.showBarcode !== false;
  const unitOptions = Array.isArray(pSchema.unitOptions) ? pSchema.unitOptions : null;
  const nameLabel  = pSchema.nameLabel        || term('product', 'Product') + ' Name';
  const descLabel  = pSchema.descriptionLabel || 'Description';
  const attrsTitle = pSchema.attributesTitle  || (term('product', 'Product') + ' Details');

  /* ── Section labels (entity-aware, from config or base defaults) ── */
  const sl = config.formSectionLabels || {};
  const labelBasics  = sl.basics  || 'Basic Information';
  const labelPricing = sl.pricing || 'Pricing';
  const labelStock   = sl.stock   || 'Stock & Inventory';
  const labelTax     = sl.tax     || 'GST & Tax';

  /* ── All state (UNCHANGED) ── */
  const [products,   setProducts]   = useState([]);
  const [filtered,   setFiltered]   = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [, setRefreshing] = useState(false);
  const [error,      setError]      = useState('');
  const [isOnline,   setIsOnline]   = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [, setCacheUpdatedAt] = useState(null);

  const [search,        setSearch]        = useState('');
  const [sortBy,        setSortBy]        = useState('name');
  const [filterStock,   setFilterStock]   = useState('all');
  const [filterCategory, setFilterCategory] = useState('');
  const [expiringFilter, setExpiringFilter] = useState(false);
  const [sizeFilter,     setSizeFilter]     = useState('');
  const [urlLowStock,    setUrlLowStock]    = useState(false);

  const [showModal,   setShowModal]   = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [form, setForm] = useState({ name:'', description:'', price:'', cost_price:'', quantity:'', unit:'pcs', barcode:'', hsn_code:'', gst_rate:0, low_stock_threshold:5, category:'', sub_category:'' });
  const [metadata, setMetadata] = useState({});
  const [metaErrors, setMetaErrors] = useState({});
  const [showBarcodeScanner, setShowBarcodeScanner] = useState(false);
  const [lastScannedBarcode, setLastScannedBarcode] = useState('');

  const [showStockModal,  setShowStockModal]  = useState(false);
  const [stockProduct,    setStockProduct]    = useState(null);
  const [stockForm,       setStockForm]       = useState({ type:'manual_add', quantity:'', note:'' });
  const [stockSubmitting, setStockSubmitting] = useState(false);

  const [showHistory,    setShowHistory]    = useState(false);
  const [historyProduct, setHistoryProduct] = useState(null);
  const [historyData,    setHistoryData]    = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const [invPanelProduct, setInvPanelProduct] = useState(null);
  const [invTab,          setInvTab]          = useState('primary');

  const [showImportModal, setShowImportModal] = useState(false);
  const [importBusy,      setImportBusy]      = useState(false);
  const [importPreview,   setImportPreview]   = useState(null);
  const [importFile,      setImportFile]      = useState(null);

  const [reorderItems,     setReorderItems]     = useState([]);
  const [showReorderPanel, setShowReorderPanel] = useState(true);

  /* ── All effects (UNCHANGED) ── */
  /* eslint-disable react-hooks/exhaustive-deps */
  useEffect(() => {
    if (!localStorage.getItem('token')) { router.push('/login'); return; }
    const cached = readPageCache(PRODUCTS_CACHE_KEY);
    if (cached?.products) { setProducts(cached.products); setCacheUpdatedAt(cached.cachedAt || null); setLoading(false); }
    const deferredId = scheduleDeferred(async () => { setRefreshing(Boolean(cached?.products)); await Promise.all([fetchProducts(), fetchReorderSuggestions()]); setRefreshing(false); });
    return () => cancelDeferred(deferredId);
  }, []);
  /* eslint-enable react-hooks/exhaustive-deps */

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const on = () => setIsOnline(true); const off = () => setIsOnline(false);
    window.addEventListener('online', on); window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('filter') === 'expiring') setExpiringFilter(true);
    if (params.get('filter') === 'low_stock') setUrlLowStock(true);
    if (params.get('size')) setSizeFilter(params.get('size'));
  }, []);

  useEffect(() => {
    let r = [...products];
    if (search)              r = r.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || (p.description && p.description.toLowerCase().includes(search.toLowerCase())) || (p.barcode && p.barcode.toLowerCase().includes(search.toLowerCase())));
    if (filterCategory)            r = r.filter(p => p.category === filterCategory);
    if (filterStock === 'low')     r = r.filter(p => p.quantity > 0 && p.is_low_stock);
    if (filterStock === 'out')     r = r.filter(p => p.quantity === 0);
    if (filterStock === 'instock') r = r.filter(p => p.quantity > 0 && !p.is_low_stock);
    if (expiringFilter) {
      const now = new Date();
      const in30 = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      r = r.filter(p => {
        const exp = p.metadata?.expiry_date;
        if (!exp) return false;
        const d = new Date(exp);
        return !isNaN(d.getTime()) && d <= in30;
      });
    }
    // Clothing: size + low_stock URL filter (from dashboard size pills)
    if (urlLowStock && sizeFilter) {
      r = r.filter(p => {
        const isLow = p.quantity <= p.low_stock_threshold;
        const meta = p.metadata || {};
        const sizes = String(meta.sizes || meta.size || '');
        return isLow && sizes.toLowerCase().includes(sizeFilter.toLowerCase());
      });
    } else if (urlLowStock && !sizeFilter) {
      r = r.filter(p => p.quantity <= p.low_stock_threshold);
    }
    if (sortBy === 'name')         r.sort((a, b) => a.name.localeCompare(b.name));
    if (sortBy === 'price_asc')    r.sort((a, b) => a.price - b.price);
    if (sortBy === 'price_desc')   r.sort((a, b) => b.price - a.price);
    if (sortBy === 'quantity')     r.sort((a, b) => a.quantity - b.quantity);
    if (sortBy === 'margin')       r.sort((a, b) => (b.margin || 0) - (a.margin || 0));
    setFiltered(r);
  }, [search, sortBy, filterStock, filterCategory, expiringFilter, urlLowStock, sizeFilter, products]);

  /* ── All logic (UNCHANGED) ── */
  const fetchProducts = async () => {
    try {
      const res = await fetch(apiUrl('/api/products'), { headers: { Authorization: `Bearer ${getToken()}` } });
      if (res.status === 401) { router.push('/login'); return; }
      const data = await res.json();
      const next = Array.isArray(data) ? data : data.products || [];
      setProducts(next);
      writePageCache(PRODUCTS_CACHE_KEY, { products: next });
      setCacheUpdatedAt(new Date().toISOString());
    } catch { setError('Products could not be loaded'); }
    finally { setLoading(false); }
  };

  const fetchReorderSuggestions = async () => {
    try {
      const res = await fetch(apiUrl('/api/products/reorder-suggestions'), { headers: { Authorization: `Bearer ${getToken()}` } });
      if (res.ok) setReorderItems(await res.json());
    } catch { /* non-critical */ }
  };

  const handleImportFileChange = async (file) => {
    if (!file) return;
    setImportFile(file);
    setImportBusy(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch(apiUrl('/api/products/bulk-import?preview=true'), {
        method: 'POST',
        headers: { Authorization: `Bearer ${getToken()}` },
        body: fd,
      });
      const data = await res.json();
      if (!res.ok) { alert(data.message || 'Preview failed'); setImportFile(null); return; }
      setImportPreview(data);
    } catch (e) {
      alert(`Preview error: ${e.message}`);
      setImportFile(null);
    } finally {
      setImportBusy(false);
    }
  };

  const handleImportConfirm = async () => {
    if (!importFile) return;
    setImportBusy(true);
    try {
      const fd = new FormData();
      fd.append('file', importFile);
      const res = await fetch(apiUrl('/api/products/bulk-import'), {
        method: 'POST',
        headers: { Authorization: `Bearer ${getToken()}` },
        body: fd,
      });
      const data = await res.json();
      if (!res.ok) { alert(data.message || 'Import failed'); return; }
      alert(`✅ Import complete: ${data.created} added, ${data.skipped} skipped${data.errors?.length ? `, ${data.errors.length} errors` : ''}`);
      setShowImportModal(false);
      setImportPreview(null);
      setImportFile(null);
      const refresh = await fetch(apiUrl('/api/products'), { headers: { Authorization: `Bearer ${getToken()}` } });
      const refreshData = await refresh.json();
      const list = Array.isArray(refreshData) ? refreshData : (refreshData.products || []);
      setProducts(list); setFiltered(list);
    } catch (e) {
      alert(`Import error: ${e.message}`);
    } finally {
      setImportBusy(false);
    }
  };

  const openAdd = () => {
    setEditProduct(null);
    setForm({ name:'', description:'', price:'', cost_price:'',
      quantity: trackQty ? '' : '0',
      unit: unitOptions ? unitOptions[0] : 'pcs',
      barcode:'', hsn_code:'', gst_rate:0, low_stock_threshold:5,
      category:'', sub_category:'' });
    setMetadata({}); setMetaErrors({});
    setLastScannedBarcode(''); setError(''); setShowModal(true);
  };

  const openEdit = (p) => {
    setEditProduct(p);
    setForm({ name:p.name, description:p.description||'', price:p.price, cost_price:p.cost_price||'', quantity:p.quantity, unit:p.unit||'pcs', barcode:p.barcode||'', hsn_code:p.hsn_code||'', gst_rate:p.gst_rate||0, low_stock_threshold:p.low_stock_threshold||5, category:p.category||'', sub_category:p.sub_category||'' });
    // Restore metadata from product (MongoDB Map serialises to plain object in JSON response)
    setMetadata(p.metadata && typeof p.metadata === 'object' ? { ...p.metadata } : {}); setMetaErrors({});
    setLastScannedBarcode(''); setError(''); setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); setError('');
    if (!isOnline) { setError('Offline mode me product save nahi hoga.'); return; }

    /* ── Schema validation for required attribute fields ── */
    const sections = config.productAttributeSections || [];
    const errs = validateSections(sections, metadata);
    if (Object.keys(errs).length > 0) {
      setMetaErrors(errs);
      setError(`Please fill in the required fields: ${Object.values(errs).join(', ')}`);
      return;
    }
    setMetaErrors({});
    const url = editProduct ? apiUrl(`/api/products/${editProduct._id}`) : apiUrl('/api/products');
    try {
      const res = await fetch(url, { method: editProduct ? 'PUT' : 'POST', headers: { 'Content-Type':'application/json', Authorization:`Bearer ${getToken()}` }, body: JSON.stringify({ ...form, metadata }) });
      const data = await res.json();
      if (res.ok) { setShowModal(false); fetchProducts(); } else setError(data.message || 'Could not save product');
    } catch { setError('Server error'); }
  };

  const handleBarcodeDetected = (code) => {
    const nb = normalizeBarcode(code);
    setForm(c => ({ ...c, barcode: nb }));
    setLastScannedBarcode(nb);
    setShowBarcodeScanner(false);
  };

  const handleDelete = async (id) => {
    if (!isOnline) { setError('Offline mode me delete nahi hoga.'); return; }
    if (!confirm('Delete this product?')) return;
    try {
      const res = await fetch(apiUrl(`/api/products/${id}`), { method:'DELETE', headers:{ Authorization:`Bearer ${getToken()}` } });
      if (res.ok) fetchProducts(); else { const d = await res.json(); setError(d.message || 'Could not delete'); }
    } catch { setError('Server error'); }
  };

  const openStockAdjust = (p) => { setStockProduct(p); setStockForm({ type:'manual_add', quantity:'', note:'' }); setError(''); setShowStockModal(true); };

  const handleStockAdjust = async (e) => {
    e.preventDefault(); setError('');
    setStockSubmitting(true);
    if (!isOnline) {
      await queueStockAdjust(stockProduct._id, { ...stockForm, product_name: stockProduct.name });
      setProducts(prev => prev.map(p => p._id === stockProduct._id
        ? { ...p, quantity: p.quantity + (stockForm.type === 'manual_add' ? Number(stockForm.quantity) : -Number(stockForm.quantity)) }
        : p
      ));
      setShowStockModal(false);
      setStockSubmitting(false);
      return;
    }
    try {
      const res = await fetch(apiUrl(`/api/products/${stockProduct._id}/adjust-stock`), { method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${getToken()}` }, body: JSON.stringify(stockForm) });
      const data = await res.json();
      if (res.ok) { setShowStockModal(false); fetchProducts(); } else setError(data.message || 'Stock update failed');
    } catch { setError('Server error'); }
    setStockSubmitting(false);
  };

  const openHistory = async (p) => {
    if (!isOnline) { setError('Offline mode me stock history load nahi hogi.'); return; }
    setHistoryProduct(p); setShowHistory(true); setHistoryLoading(true);
    try {
      const res  = await fetch(apiUrl(`/api/products/${p._id}/stock-history`), { headers:{ Authorization:`Bearer ${getToken()}` } });
      const data = await res.json();
      setHistoryData(data.history || []);
    } catch {}
    setHistoryLoading(false);
  };

  /* ── Inventory behavior ── */
  const inv          = getInvBehavior(config);
  const showInvPanel = hasInventoryPanel(inv);

  const openInvPanel = (p) => {
    setInvPanelProduct(p);
    setInvTab('primary');
  };

  /* ── Computed ── */
  const lowStockCount   = products.filter(p => p.is_low_stock && p.quantity > 0).length;
  const outOfStockCount = products.filter(p => p.quantity === 0).length;
  const totalValue      = products.reduce((s, p) => s + (p.cost_price || 0) * p.quantity, 0);
  const suggestedGstRate = (() => { const prefix = parseInt(String(form.hsn_code || '').slice(0,2), 10); return HSN_GST_HINTS[prefix]; })();
  const liveMargin = form.cost_price && form.price && Number(form.cost_price) > 0
    ? (((Number(form.price) - Number(form.cost_price)) / Number(form.cost_price)) * 100).toFixed(1) : null;
  const liveProfit = liveMargin != null ? (Number(form.price) - Number(form.cost_price)).toFixed(2) : null;
  const liveMrp = form.mrp ? Number(form.mrp) : null;
  const mrpViolation = liveMrp && form.price && Number(form.price) > liveMrp;
  const STOCK_TYPES = {
    manual_add:    { label:'Stock जोड़ो',   color:'border-emerald-400 bg-emerald-50 text-emerald-800', active:'bg-emerald-500 text-white border-emerald-500' },
    manual_remove: { label:'Stock हटाओ',   color:'border-rose-400 bg-rose-50 text-rose-800',         active:'bg-rose-500 text-white border-rose-500' },
    adjustment:    { label:'Correction',   color:'border-amber-400 bg-amber-50 text-amber-800',          active:'bg-amber-500 text-white border-amber-500' },
  };

  /* ════════════════════════════════════════════════════════════════
     RENDER
  ════════════════════════════════════════════════════════════════ */
  return (
    <Layout>
      <div className="desktop-expand max-w-2xl mx-auto px-3 sm:px-4 pt-4 pb-28 space-y-4">

        {/* ── OFFLINE BANNER ── */}
        {!isOnline && (
          <div className="flex items-start gap-3 px-4 py-3.5 rounded-2xl bg-amber-50 border border-amber-200">
            <span className="text-xl">📶</span>
            <div>
              <p className="text-[13px] font-black text-amber-900">Offline Stock Mode</p>
              <p className="text-[11px] text-amber-700 mt-0.5">Add, edit, delete aur stock actions internet wapas aane par hi chalenge.</p>
            </div>
          </div>
        )}

        {/* ── HEADER ── */}
        <div className="rr-page-hero rr-fade-in">
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="rr-section-label">📦 {term('inventory', 'Stock')}</span>
              <PageHeader title="स्टॉक" subtitle="सामान और इन्वेंटरी" />
            </div>
            <button
              type="button"
              onClick={() => setShowImportModal(true)}
              className="action-soft flex items-center gap-1.5 px-3 py-2 text-[12px]"
            >📥 Excel / CSV Import</button>
            <button onClick={openAdd} disabled={!isOnline}
              className="flex-shrink-0 inline-flex items-center gap-2 px-5 py-3 rounded-xl text-[14px] font-black text-white bg-gradient-to-r from-green-600 to-emerald-700 shadow-lg shadow-green-500/30 hover:-translate-y-1 hover:shadow-xl disabled:opacity-50 transition-all"
            >+ {term('addProduct', 'Add Product')}</button>
          </div>
        </div>

        {expiringFilter && (
          <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-orange-50 border-2 border-orange-300">
            <span className="text-xl flex-shrink-0">⏰</span>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-black text-orange-900">
                Showing items with expiry within 30 days — {filtered.length} items
              </p>
              <p className="text-[11px] text-orange-700 mt-0.5">Review and clear near-expiry stock immediately</p>
            </div>
            <button
              onClick={() => { setExpiringFilter(false); window.history.replaceState({}, '', '/product'); }}
              className="flex-shrink-0 px-3 py-1.5 rounded-lg border border-orange-300 bg-white text-[11px] font-bold text-orange-700 hover:bg-orange-50 transition-colors"
            >Clear Filter</button>
          </div>
        )}

        {/* ── CLOTHING SIZE LOW-STOCK FILTER BANNER ── */}
        {urlLowStock && sizeFilter && (
          <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-amber-50 border-2 border-amber-300">
            <span className="text-xl flex-shrink-0">📏</span>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-black text-amber-900">
                Showing Size {sizeFilter} low-stock garments — {filtered.length} item{filtered.length !== 1 ? 's' : ''}
              </p>
              <p className="text-[11px] text-amber-700 mt-0.5">These products are at or below their reorder threshold for this size</p>
            </div>
            <button
              onClick={() => { setSizeFilter(''); setUrlLowStock(false); window.history.replaceState({}, '', '/product'); }}
              className="flex-shrink-0 px-3 py-1.5 rounded-lg border border-amber-300 bg-white text-[11px] font-bold text-amber-700 hover:bg-amber-50 transition-colors"
            >Clear</button>
          </div>
        )}

        {/* ── KPI STRIP ── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: term('kpiTotalProducts', 'Total Products'),  value: products.length,                                      gradient:'from-green-50 to-emerald-100', border:'border-green-200', vc:'text-green-800', icon:'📦' },
            { label: term('kpiLowStock', 'Low Stock'),            value: lowStockCount,                                        gradient:'from-amber-50 to-orange-100',   border:'border-amber-200',   vc:'text-amber-800', icon:'⚠️'  },
            { label: term('kpiOutOfStock', 'Out of Stock'),       value: outOfStockCount,                                      gradient:'from-rose-50 to-red-100',     border:'border-rose-200',     vc:'text-rose-800', icon:'❌'   },
            { label: term('kpiInventoryValue', 'Inventory Value'), value: `₹${Math.round(totalValue).toLocaleString('en-IN')}`, gradient:'from-emerald-50 to-green-100', border:'border-emerald-200', vc:'text-emerald-800', icon:'💰' },
          ].map(k => (
            <div key={k.label} className={`relative overflow-hidden bg-gradient-to-br ${k.gradient} border-2 ${k.border} rounded-2xl p-4 shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all`}>
              <div className="absolute top-2 right-2 text-2xl opacity-10">{k.icon}</div>
              <p className={`text-[22px] font-black leading-none ${k.vc}`}>{k.value}</p>
              <p className="text-[10px] font-bold text-slate-600 mt-1.5 uppercase tracking-wide leading-tight">{k.label}</p>
            </div>
          ))}
        </div>

        {/* ── REORDER SUGGESTIONS ── */}
        {reorderItems.length > 0 && showReorderPanel && (
          <div className="rounded-2xl border-2 border-amber-300 bg-amber-50 p-4 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <p className="text-[13px] font-black text-amber-900">⚠️ {reorderItems.length} item{reorderItems.length !== 1 ? 's' : ''} need restocking</p>
              <button onClick={() => setShowReorderPanel(false)} className="text-amber-500 hover:text-amber-700 text-lg leading-none">✕</button>
            </div>
            <div className="space-y-1.5 max-h-40 overflow-y-auto">
              {reorderItems.slice(0, 10).map(p => (
                <div key={p._id} className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-white border border-amber-200">
                  <div className="min-w-0">
                    <p className="text-[12px] font-bold text-slate-800 truncate">{p.name}</p>
                    {p.category && <p className="text-[10px] text-slate-400">{p.category}</p>}
                  </div>
                  <span className={`flex-shrink-0 text-[11px] font-black px-2 py-0.5 rounded-lg ${p.quantity === 0 ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'}`}>
                    {p.quantity === 0 ? 'Out' : `${p.quantity} ${p.unit || 'pcs'}`}
                  </span>
                </div>
              ))}
            </div>
            {reorderItems.length > 10 && (
              <p className="text-[10px] text-amber-600 text-center">+{reorderItems.length - 10} more — use &quot;Low Stock&quot; filter to see all</p>
            )}
          </div>
        )}

        {/* ── TOOLBAR ── */}
        <div className="bg-white rounded-2xl border-2 border-slate-200 p-4 shadow-md space-y-3">
          <input className="h-11 w-full px-4 rounded-xl border-2 border-slate-200 bg-slate-50 text-[13px] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-600 transition-all"
            placeholder="🔍 नाम, barcode या category..."
            value={search} onChange={e => setSearch(e.target.value)}
          />
          <div className="flex gap-2">
            {config.categoryConfig && (
              <select className="flex-1 h-11 px-4 rounded-xl border-2 border-slate-200 bg-slate-50 text-[13px] text-slate-700 focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-600 transition-all"
                value={filterCategory} onChange={e => setFilterCategory(e.target.value)}>
                <option value="">All Categories</option>
                {config.categoryConfig.categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            )}
            <select className="flex-1 h-11 px-4 rounded-xl border-2 border-slate-200 bg-slate-50 text-[13px] text-slate-700 focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-600 transition-all"
              value={filterStock} onChange={e => setFilterStock(e.target.value)}>
              <option value="all">All Stock</option>
              <option value="instock">In Stock</option>
              <option value="low">Low Stock</option>
              <option value="out">Out of Stock</option>
            </select>
            <select className="flex-1 h-11 px-4 rounded-xl border-2 border-slate-200 bg-slate-50 text-[13px] text-slate-700 focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-600 transition-all"
              value={sortBy} onChange={e => setSortBy(e.target.value)}>
              <option value="name">Sort: Name</option>
              <option value="price_asc">Price: Low → High</option>
              <option value="price_desc">Price: High → Low</option>
              <option value="quantity">Qty: Low → High</option>
              <option value="margin">Margin: Best</option>
            </select>
            {(search || filterStock !== 'all' || filterCategory) && (
              <button onClick={() => { setSearch(''); setFilterStock('all'); setFilterCategory(''); }}
                className="px-4 h-11 rounded-xl border-2 border-slate-200 text-[12px] font-bold text-slate-500 hover:bg-slate-50 transition-colors"
              >Clear</button>
            )}
          </div>
        </div>

        {/* ── PAGE ERROR ── */}
        {error && !showModal && !showStockModal && (
          <div className="flex items-center gap-2.5 px-4 py-3 rounded-xl bg-rose-50 border border-rose-200 text-[13px] font-semibold text-rose-700">
            ⚠️ {error}
          </div>
        )}

        {/* ── LOADING ── */}
        {loading && (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="skeleton-card border border-slate-200/80" style={{ height: 96 }} />
            ))}
          </div>
        )}

        {/* ── EMPTY STATE ── */}
        {!loading && filtered.length === 0 && (
          search || filterStock !== 'all' ? (
            <div className="rr-empty">
              <div className="rr-empty-icon">🔍</div>
              <p className="rr-empty-title">कोई सामान नहीं मिला</p>
              <p className="rr-empty-sub">अलग keyword try करें</p>
            </div>
          ) : (
            <div className="rr-empty">
              <div className="rr-empty-icon">📦</div>
              <p className="rr-empty-title">कोई {term('product', 'product')} नहीं मिला</p>
              <p className="rr-empty-sub">पहला product add करो और billing शुरू करो।</p>
            </div>
          )
        )}

        {/* ── PRODUCT CARDS ── */}
        {!loading && filtered.length > 0 && (
          <>
            <div className="rr-section-head">
              <span className="rr-section-label">{term('products', 'Products')} · {filtered.length} items</span>
              <button onClick={openAdd} disabled={!isOnline} className="rr-section-link">+ {term('addProduct', 'Add Product')}</button>
            </div>
            <div className="flex flex-col gap-3">
              {filtered.map(p => {
                const s = stockStatus(p);
                return (
                  <div key={p._id}
                    className={`rr-accent-card transition-all duration-200 hover:-translate-y-[1px] ${
                      p.quantity === 0 ? 'accent-rose' : p.is_low_stock ? 'accent-amber' : 'accent-green'
                    }`}
                  >
                    <div className="p-0">
                      {/* Top row */}
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <div className="min-w-0">
                          <p className="text-[15px] font-black text-slate-900 leading-tight">{p.name}</p>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            {[p.barcode && `📷 ${p.barcode}`, p.hsn_code && `HSN ${p.hsn_code}`, p.unit].filter(Boolean).join(' · ')}
                          </p>
                          {p.category && (
                            <span className="inline-block mt-1 px-2 py-0.5 rounded-full bg-indigo-50 border border-indigo-100 text-[10px] font-semibold text-indigo-600">
                              {p.category}{p.sub_category ? ` › ${p.sub_category}` : ''}
                            </span>
                          )}
                        </div>
                        <span className={`rr-pill flex-shrink-0 ${p.quantity === 0 ? 'rr-pill-rose' : p.is_low_stock ? 'rr-pill-amber' : 'rr-pill-green'}`}>
                          {s.label}
                        </span>
                      </div>

                      {/* Stats grid */}
                      <div className={`grid gap-2 mb-3 ${isSerialMode(inv) ? 'grid-cols-6' : 'grid-cols-5'}`}>
                        {[
                          { label: 'Cost',   value: p.cost_price ? '₹' + parseFloat(p.cost_price || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—', cls: 'text-slate-600' },
                          { label: 'Price',  value: '₹' + parseFloat(p.price || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }), cls: 'text-slate-900 font-black' },
                          { label: 'Margin', value: p.margin != null ? `${p.margin}%` : '—',  cls: marginColor(p.margin) + ' font-black' },
                          { label: isSerialMode(inv) ? 'Units' : 'Qty', value: `${p.quantity}`, cls: (p.quantity === 0 ? 'text-rose-600' : p.is_low_stock ? 'text-amber-600' : 'text-emerald-600') + ' font-black text-[16px]' },
                          ...(isSerialMode(inv) ? [{ label: 'Serials', value: `${p.serial_count ?? p.quantity}`, cls: 'text-indigo-600 font-black text-[16px]' }] : []),
                          { label: 'GST',    value: p.gst_rate > 0 ? `${p.gst_rate}%` : 'NIL', cls: 'text-green-700 font-bold' },
                        ].map(item => (
                          <div key={item.label} className="text-center">
                            <p className="text-[9px] font-bold uppercase tracking-wider text-slate-400 mb-1">{item.label}</p>
                            <p className={`text-[13px] font-semibold text-slate-800 ${item.cls}`}>{item.value}</p>
                          </div>
                        ))}
                      </div>
                      {isSerialMode(inv) && (
                        <div className="flex items-center gap-1.5 mb-2">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-indigo-50 border border-indigo-100 text-[10px] font-bold text-indigo-600">🔢 IMEI/Serial tracked</span>
                        </div>
                      )}

                      {/* Industry-specific attribute pills (supports sections + flat attributes) */}
                      {(() => {
                        const allFields = config.productAttributeSections?.length
                          ? flattenSectionFields(config.productAttributeSections)
                          : (config.productAttributes || []);
                        const pills = allFields
                          .map(f => ({ label: f.label, value: formatMetaValue((p.metadata || {})[f.key]) }))
                          .filter(pill => pill.value);
                        if (!pills.length) return null;
                        return (
                          <div className="flex flex-wrap gap-1.5 mb-3 pt-2 border-t border-slate-100">
                            {pills.map(pill => (
                              <span key={pill.label} className="px-2 py-0.5 rounded-full bg-indigo-50 border border-indigo-100 text-[10px] font-semibold text-indigo-600">
                                {pill.label}: {pill.value}
                              </span>
                            ))}
                          </div>
                        );
                      })()}

                      {/* Action buttons */}
                      {showInvPanel && (
                        <button onClick={() => openInvPanel(p)}
                          className="w-full py-2 rounded-xl border border-indigo-200 bg-indigo-50 text-[11px] font-bold text-indigo-700 hover:bg-indigo-100 transition-colors mb-2"
                        >🧮 {getPrimaryPanelLabel(inv)}</button>
                      )}
                      <div className="grid grid-cols-4 gap-2">
                        <button onClick={() => openStockAdjust(p)}
                          className="action-soft stock py-2 text-[11px] font-bold transition-all"
                        >Stock</button>
                        <button onClick={() => openHistory(p)}
                          className="action-soft history py-2 text-[11px] font-bold transition-all"
                        >History</button>
                        <button onClick={() => openEdit(p)}
                          className="action-soft edit py-2 text-[11px] font-bold transition-all"
                        >Edit</button>
                        <button onClick={() => handleDelete(p._id)}
                          className="action-soft delete py-2 text-[11px] font-bold transition-all"
                        >Delete</button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Result count */}
            <p className="text-center text-[11px] text-slate-400 pb-2">
              {filtered.length} of {products.length} {term('products', 'products')}
            </p>
          </>
        )}
      </div>

      {/* ════════════════════════════════════════════════════════════
          ADD / EDIT MODAL
      ════════════════════════════════════════════════════════════ */}
      {showModal && (
        <Backdrop onClose={() => setShowModal(false)}>
          <div className="w-full sm:max-w-[520px] max-h-[92dvh] sm:max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white shadow-2xl">
            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1 sm:hidden flex-shrink-0">
              <div className="w-10 h-1 rounded-full bg-slate-200" />
            </div>

            {/* Header */}
            <div className="sticky top-0 z-10 bg-white border-b border-slate-100 px-5 py-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{editProduct ? `Edit ${term('product','Product')}` : `New ${term('product','Product')}`}</p>
                  <h3 className="text-[18px] font-black text-slate-900 mt-0.5">{editProduct ? editProduct.name : `${term('product','Product')} Add करो`}</h3>
                </div>
                <button onClick={() => setShowModal(false)}
                  className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-colors"
                >✕</button>
              </div>
            </div>

            <div className="px-5 py-4 space-y-4">
              {error && <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-rose-50 border border-rose-200 text-[13px] font-semibold text-rose-700">⚠️ {error}</div>}

              <form onSubmit={handleSubmit} className="space-y-4">

                {/* ── BASICS ── */}
                <div className="rounded-2xl border border-slate-100 bg-slate-50/80 p-4 space-y-3">
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">{labelBasics}</p>
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">{nameLabel} *</p>
                    <input className={INP} value={form.name} onChange={e => setForm({...form, name:e.target.value})} required placeholder={nameLabel} />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">{descLabel}</p>
                    <input className={INP} value={form.description} onChange={e => setForm({...form, description:e.target.value})} placeholder={descLabel} />
                  </div>
                  {showBarcode && (
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Barcode</p>
                      <div className="flex gap-2">
                        <input className={`${INP} flex-1`} placeholder="Scan or type barcode"
                          value={form.barcode}
                          onChange={e => { const nb = normalizeBarcode(e.target.value); setForm({...form, barcode:nb}); setLastScannedBarcode(c => c===nb?c:''); }}
                        />
                        <button type="button" onClick={() => setShowBarcodeScanner(true)}
                          className="px-4 h-11 rounded-xl border border-slate-200 bg-white text-[12px] font-bold text-slate-600 hover:bg-slate-50 flex-shrink-0 transition-colors"
                        >📷 Scan</button>
                      </div>
                      {lastScannedBarcode && (
                        <div className="mt-2 flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-[12px] font-semibold text-emerald-700">
                          ✓ Scanned: <span className="font-mono font-black">{lastScannedBarcode}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* ── PRICING ── */}
                <div className="rounded-2xl border border-slate-100 bg-slate-50/80 p-4 space-y-3">
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">{labelPricing}</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Cost Price</p>
                      <input className={INP} type="number" step="0.01" placeholder="Your cost" value={form.cost_price} onChange={e => setForm({...form, cost_price:e.target.value})} />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                        Selling Price *
                        {liveMrp && <span className="text-slate-400 font-normal ml-1">(MRP: ₹{liveMrp})</span>}
                      </p>
                      <input className={`${INP} ${mrpViolation ? 'border-red-400 focus:border-red-500' : ''}`} type="number" step="0.01" placeholder="Customer pays" value={form.price} onChange={e => setForm({...form, price:e.target.value})} required />
                      {mrpViolation && (
                        <p className="text-red-600 text-[10px] font-semibold mt-1">
                          ⚠️ Selling price ₹{form.price} MRP ₹{liveMrp} से ज़्यादा है — DPCO violation
                        </p>
                      )}
                      {!mrpViolation && liveMrp && form.price && Number(form.price) < liveMrp && (
                        <p className="text-green-600 text-[10px] mt-1">
                          ✓ ₹{(liveMrp - Number(form.price)).toFixed(2)} discount below MRP
                        </p>
                      )}
                    </div>
                  </div>
                  {liveMargin !== null && (
                    <div className="flex items-center justify-between px-4 py-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                      <span className="text-[13px] font-bold text-emerald-700">Margin: <strong>{liveMargin}%</strong></span>
                      <span className="text-[12px] text-emerald-600 font-semibold">₹{liveProfit} per unit</span>
                    </div>
                  )}
                </div>

                {/* ── STOCK ── */}
                <div className="rounded-2xl border border-slate-100 bg-slate-50/80 p-4 space-y-3">
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">{labelStock}</p>
                  <div className="grid grid-cols-2 gap-3">
                    {trackQty && (
                      <div>
                        <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">{editProduct ? 'Quantity' : 'Opening Stock *'}</p>
                        <input className={INP} type="number" min="0" value={form.quantity} onChange={e => setForm({...form, quantity:e.target.value})} required={!editProduct} />
                        {editProduct && <p className="text-[10px] text-slate-400 mt-1">Stock action se adjust karo</p>}
                      </div>
                    )}
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Unit</p>
                      {unitOptions ? (
                        <select className={SEL} value={form.unit} onChange={e => setForm({...form, unit:e.target.value})}>
                          {unitOptions.map(u => <option key={u} value={u}>{u}</option>)}
                        </select>
                      ) : (
                        <input className={INP} placeholder="pcs, kg, litre..." value={form.unit||'pcs'} onChange={e => setForm({...form, unit:e.target.value})} />
                      )}
                    </div>
                  </div>
                  {trackQty && (
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Low Stock Alert ≤</p>
                      <input className={INP} type="number" min="0" placeholder="Default: 5" value={form.low_stock_threshold} onChange={e => setForm({...form, low_stock_threshold:e.target.value})} />
                    </div>
                  )}
                </div>

                {/* ── GST & TAX ── */}
                <div className="rounded-2xl border border-slate-100 bg-slate-50/80 p-4 space-y-3">
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">{labelTax}</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">HSN/SAC Code</p>
                      <input className={INP} placeholder="e.g. 8471"
                        value={form.hsn_code}
                        onChange={e => {
                          const v = e.target.value.replace(/\D/g,'').slice(0,8);
                          const prefix = parseInt(v.slice(0,2),10);
                          const suggested = HSN_GST_HINTS[prefix];
                          setForm(c => ({ ...c, hsn_code:v, gst_rate: suggested ?? c.gst_rate }));
                        }}
                      />
                      {suggestedGstRate !== undefined && (
                        <p className="text-[10px] text-green-700 mt-1">Suggested GST: {suggestedGstRate}%</p>
                      )}
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">GST Rate</p>
                      <select className={SEL} value={form.gst_rate} onChange={e => setForm({...form, gst_rate:parseInt(e.target.value)})}>
                        <option value={0}>0% — No GST</option>
                        <option value={5}>5% GST</option>
                        <option value={12}>12% GST</option>
                        <option value={18}>18% GST</option>
                        <option value={28}>28% GST</option>
                      </select>
                    </div>
                  </div>
                  {form.price && form.gst_rate > 0 && (
                    <div className="flex items-center justify-between px-4 py-2.5 rounded-xl bg-green-50 border border-green-200 text-[12px]">
                      <span className="text-slate-500">GST Preview</span>
                      <span className="font-bold text-green-700">
                        ₹{parseFloat(form.price||0).toFixed(2)} + {form.gst_rate}% = <strong>₹{(parseFloat(form.price||0)*(1+form.gst_rate/100)).toFixed(2)}</strong>
                      </span>
                    </div>
                  )}
                </div>

                {/* ── CATEGORY ── */}
                {config.categoryConfig && (
                  <div className="rounded-2xl border border-slate-100 bg-slate-50/80 p-4 space-y-3">
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Category</p>
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Category</p>
                      <select className={SEL} value={form.category}
                        onChange={e => setForm(prev => ({ ...prev, category: e.target.value, sub_category: '' }))}>
                        <option value="">— Select Category —</option>
                        {config.categoryConfig.categories.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    {form.category && config.categoryConfig.subCategories[form.category]?.length > 0 && (
                      <div>
                        <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Sub-Category</p>
                        <select className={SEL} value={form.sub_category}
                          onChange={e => setForm(prev => ({ ...prev, sub_category: e.target.value }))}>
                          <option value="">— All Sub-categories —</option>
                          {config.categoryConfig.subCategories[form.category].map(sc => <option key={sc} value={sc}>{sc}</option>)}
                        </select>
                      </div>
                    )}
                  </div>
                )}

                {/* ── INDUSTRY-SPECIFIC ATTRIBUTES (sections take priority over flat list) ── */}
                {config.productAttributeSections?.length > 0
                  ? config.productAttributeSections.map(section => {
                      if (section.visibleWhenCategory && section.visibleWhenCategory !== form.category) return null;
                      return (
                        <DynamicFormSection
                          key={section.title}
                          section={section}
                          values={metadata}
                          onChange={(key, v) => { setMetadata(prev => ({ ...prev, [key]: v })); setMetaErrors(prev => { const n = { ...prev }; delete n[key]; return n; }); }}
                          errors={metaErrors}
                        />
                      );
                    })
                  : config.productAttributes?.length > 0 && (
                      <div className="rounded-2xl border border-green-100 bg-green-50/60 p-4 space-y-3">
                        <p className="text-[10px] font-black uppercase tracking-widest text-green-700">{attrsTitle}</p>
                        {config.productAttributes.map(attr => (
                          <div key={attr.key}>
                            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">{attr.label}</p>
                            <DynamicFormField
                              field={attr}
                              value={metadata[attr.key] || ''}
                              onChange={v => setMetadata(prev => ({ ...prev, [attr.key]: v }))}
                            />
                          </div>
                        ))}
                      </div>
                    )
                }

                {/* Submit */}
                <div className="flex gap-3 pb-2">
                  <button type="submit" disabled={!!mrpViolation}
                    className="flex-1 py-3.5 rounded-2xl text-[14px] font-black text-white bg-gradient-to-r from-green-600 to-emerald-700 shadow-lg shadow-green-600/20 hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:translate-y-0"
                  >{editProduct ? `✓ Update ${term('product','Product')}` : `+ ${term('addProduct','Add Product')}`}</button>
                  <button type="button" onClick={() => setShowModal(false)}
                    className="flex-1 py-3.5 rounded-2xl border border-slate-200 text-[14px] font-bold text-slate-600 hover:bg-slate-50 transition-colors"
                  >Cancel</button>
                </div>
              </form>
            </div>
          </div>
        </Backdrop>
      )}

      {/* ════════════════════════════════════════════════════════════
          STOCK ADJUST MODAL
      ════════════════════════════════════════════════════════════ */}
      {showStockModal && stockProduct && (
        <Backdrop onClose={() => { setShowStockModal(false); setError(''); }}>
          <div className="w-full sm:max-w-[420px] rounded-t-3xl sm:rounded-3xl bg-white shadow-2xl overflow-hidden">
            <div className="flex justify-center pt-3 pb-1 sm:hidden">
              <div className="w-10 h-1 rounded-full bg-slate-200" />
            </div>

            {/* Header */}
            <div className="px-5 py-4 border-b border-slate-100 flex items-start justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Stock Adjustment</p>
                <h3 className="text-[17px] font-black text-slate-900 mt-0.5">{stockProduct.name}</h3>
                <div className="mt-2 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-[12px] font-semibold text-slate-700">
                  Current: <strong className="text-slate-900">{stockProduct.quantity} {stockProduct.unit || 'pcs'}</strong>
                </div>
              </div>
              <button onClick={() => { setShowStockModal(false); setError(''); }}
                className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-colors"
              >✕</button>
            </div>

            <div className="px-5 py-4 space-y-4">
              {error && <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-rose-50 border border-rose-200 text-[13px] font-semibold text-rose-700">⚠️ {error}</div>}

              <form onSubmit={handleStockAdjust} className="space-y-4">
                {/* Type toggle */}
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Adjustment Type</p>
                  <div className="grid grid-cols-3 gap-2">
                    {Object.entries(STOCK_TYPES).map(([val, cfg]) => (
                      <button key={val} type="button" onClick={() => setStockForm({...stockForm, type:val})}
                        className={`py-3 rounded-xl border-2 text-[11px] font-black transition-all ${
                          stockForm.type === val ? cfg.active : 'border-slate-200 bg-white text-slate-600'
                        }`}
                      >{cfg.label}</button>
                    ))}
                  </div>
                </div>

                {/* Quantity */}
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Quantity *</p>
                  <input className={INP} type="number" min="1" placeholder="Kitne units?"
                    value={stockForm.quantity} onChange={e => setStockForm({...stockForm, quantity:e.target.value})} required
                  />
                  {stockForm.quantity && (
                    <div className="mt-2 flex items-center justify-between px-4 py-2.5 rounded-xl bg-blue-50 border border-blue-200 text-[12px] font-semibold text-blue-700">
                      <span>New stock →</span>
                      <strong className="text-[14px]">
                        {stockForm.type === 'manual_remove'
                          ? Math.max(0, stockProduct.quantity - Number(stockForm.quantity))
                          : stockProduct.quantity + Number(stockForm.quantity)
                        } {stockProduct.unit || 'pcs'}
                      </strong>
                    </div>
                  )}
                </div>

                {/* Note */}
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Note (optional)</p>
                  <input className={INP} placeholder="Adjustment का reason..." value={stockForm.note} onChange={e => setStockForm({...stockForm, note:e.target.value})} />
                </div>

                <div className="flex gap-3 pb-2">
                  <button type="submit" disabled={stockSubmitting}
                    className="flex-1 py-3.5 rounded-2xl text-[14px] font-black text-white bg-gradient-to-r from-emerald-500 to-green-600 shadow-lg shadow-emerald-500/20 hover:-translate-y-0.5 disabled:opacity-60 disabled:translate-y-0 transition-all"
                  >{stockSubmitting ? '⏳ Saving...' : '✓ Stock Update करो'}</button>
                  <button type="button" onClick={() => { setShowStockModal(false); setError(''); }}
                    className="flex-1 py-3.5 rounded-2xl border border-slate-200 text-[14px] font-bold text-slate-600 hover:bg-slate-50 transition-colors"
                  >Cancel</button>
                </div>
              </form>
            </div>
          </div>
        </Backdrop>
      )}

      {/* ════════════════════════════════════════════════════════════
          STOCK HISTORY MODAL
      ════════════════════════════════════════════════════════════ */}
      {showHistory && historyProduct && (
        <Backdrop onClose={() => setShowHistory(false)}>
          <div className="w-full sm:max-w-[480px] max-h-[85dvh] sm:max-h-[85vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white shadow-2xl">
            <div className="flex justify-center pt-3 pb-1 sm:hidden sticky top-0">
              <div className="w-10 h-1 rounded-full bg-slate-200" />
            </div>

            {/* Header */}
            <div className="sticky top-0 bg-white border-b border-slate-100 px-5 py-4 flex items-start justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Stock History</p>
                <h3 className="text-[16px] font-black text-slate-900 mt-0.5">{historyProduct.name}</h3>
                <p className="text-[12px] text-slate-400 mt-0.5">
                  Current: <strong className="text-slate-900">{historyProduct.quantity} {historyProduct.unit||'pcs'}</strong>
                </p>
              </div>
              <button onClick={() => setShowHistory(false)}
                className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-colors"
              >✕</button>
            </div>

            <div className="px-4 py-4">
              {historyLoading ? (
                <div className="space-y-2">{[...Array(4)].map((_, i) => <div key={i} className="h-14 rounded-xl bg-slate-100 animate-pulse" />)}</div>
              ) : historyData.length === 0 ? (
                <div className="p-8 text-center">
                  <div className="text-3xl mb-2">🕐</div>
                  <p className="text-[13px] font-bold text-slate-600">कोई history नहीं मिली</p>
                </div>
              ) : (
                <div className="space-y-2 pb-4">
                  {historyData.map((h, i) => {
                    const isAdd = h.quantity_change > 0;
                    return (
                      <div key={i}
                        className={`flex items-center gap-3 px-4 py-3 rounded-xl border-l-4 ${isAdd ? 'bg-emerald-50 border-emerald-400' : 'bg-rose-50 border-rose-400'}`}
                      >
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-[15px] font-black flex-shrink-0 ${isAdd ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                          {isAdd ? '+' : '−'}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-bold text-slate-900">{historyTypeLabel(h.type)}</p>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            {new Date(h.date).toLocaleDateString('en-IN')}{h.note ? ` · ${h.note}` : ''}
                          </p>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className={`text-[15px] font-black ${isAdd ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {isAdd ? '+' : ''}{h.quantity_change}
                          </p>
                          <p className="text-[10px] text-slate-400">→ {h.quantity_after} {historyProduct.unit||'pcs'}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </Backdrop>
      )}

      {/* ════════════════════════════════════════════════════════════
          ADVANCED INVENTORY PANEL MODAL
      ════════════════════════════════════════════════════════════ */}
      {invPanelProduct && (
        <Backdrop onClose={() => setInvPanelProduct(null)}>
          <div className="w-full sm:max-w-[580px] max-h-[92dvh] sm:max-h-[90vh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-white shadow-2xl overflow-hidden">
            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1 sm:hidden flex-shrink-0">
              <div className="w-10 h-1 rounded-full bg-slate-200" />
            </div>

            {/* Header */}
            <div className="sticky top-0 z-10 bg-white border-b border-slate-100 px-5 py-4 flex-shrink-0">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Advanced Inventory</p>
                  <h3 className="text-[17px] font-black text-slate-900 mt-0.5">{invPanelProduct.name}</h3>
                  <p className="text-[12px] text-slate-400 mt-0.5">
                    Stock: <strong className="text-slate-700">{invPanelProduct.quantity} {invPanelProduct.unit || 'pcs'}</strong>
                  </p>
                </div>
                <button onClick={() => setInvPanelProduct(null)}
                  className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-colors"
                >✕</button>
              </div>

              {/* Tabs — only shown when multiple panels are available */}
              {(() => {
                const tabs = [];
                if (isBatchMode(inv))   tabs.push({ key: 'primary', label: inv.batchLabel   || 'Batches' });
                if (isVariantMode(inv)) tabs.push({ key: 'variant',  label: inv.variantLabel || 'Variants' });
                if (isSerialMode(inv))  tabs.push({ key: 'serial',   label: inv.serialLabel  || 'Serials' });
                if (isRecipeMode(inv))  tabs.push({ key: 'recipe',   label: inv.recipeLabel  || 'Recipe' });
                if (tabs.length <= 1) return null;
                return (
                  <div className="flex gap-1.5 mt-3 overflow-x-auto">
                    {tabs.map(t => (
                      <button key={t.key} onClick={() => setInvTab(t.key)}
                        className={`px-3 py-1.5 rounded-lg text-[12px] font-semibold whitespace-nowrap transition-all ${
                          invTab === t.key
                            ? 'bg-green-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >{t.label}</button>
                    ))}
                  </div>
                );
              })()}
            </div>

            {/* Panel content */}
            <div className="flex-1 overflow-y-auto px-5 py-4">
              {(() => {
                const onStockChange = () => fetchProducts();
                if (invTab === 'primary') {
                  if (isBatchMode(inv))   return <BatchInventoryPanel   productId={invPanelProduct._id} inv={inv} onStockChange={onStockChange} />;
                  if (isVariantMode(inv)) return <VariantInventoryPanel productId={invPanelProduct._id} basePrice={invPanelProduct.price} inv={inv} onStockChange={onStockChange} />;
                  if (isSerialMode(inv))  return <SerialInventoryPanel  productId={invPanelProduct._id} inv={inv} onStockChange={onStockChange} />;
                  if (isRecipeMode(inv))  return <RecipePanel           productId={invPanelProduct._id} dishName={invPanelProduct.name} inv={inv} />;
                }
                if (invTab === 'variant') return <VariantInventoryPanel productId={invPanelProduct._id} basePrice={invPanelProduct.price} inv={inv} onStockChange={onStockChange} />;
                if (invTab === 'serial')  return <SerialInventoryPanel  productId={invPanelProduct._id} inv={inv} onStockChange={onStockChange} />;
                if (invTab === 'recipe')  return <RecipePanel           productId={invPanelProduct._id} dishName={invPanelProduct.name} inv={inv} />;
                return null;
              })()}
            </div>
          </div>
        </Backdrop>
      )}

      {/* Barcode scanner (UNCHANGED) */}
      <CameraBarcodeScanner
        open={showBarcodeScanner}
        title="Scan product barcode"
        description="Camera scan se barcode field auto-fill ho jayegi."
        onClose={() => setShowBarcodeScanner(false)}
        onDetected={handleBarcodeDetected}
      />

      {showImportModal && (
        <div className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center bg-slate-900/50 backdrop-blur-sm p-0 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-[18px] font-black text-slate-900">Excel / CSV Import</h3>
                <p className="text-[12px] text-slate-500 mt-0.5">Products को Excel या CSV file से import करें</p>
              </div>
              <button type="button" onClick={() => { setShowImportModal(false); setImportPreview(null); setImportFile(null); }} className="w-8 h-8 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 text-[16px]">✕</button>
            </div>

            {!importPreview ? (
              <>
                <div className="rounded-xl bg-slate-50 border border-slate-200 p-4 text-[12px] text-slate-600 mb-4">
                  <p className="font-bold text-slate-800 mb-1">Supported columns:</p>
                  <code className="block text-[10px] font-mono text-slate-700 leading-5">
                    name, price, MRP, Dealer Price, Project Price,<br/>
                    cost_price, quantity, unit, HSN, GST %, barcode, category, brand
                  </code>
                  <a
                    href={`data:text/csv;charset=utf-8,name,price,cost_price,quantity,unit,gst_rate,hsn_code,barcode,low_stock_threshold%0ASample Product,100,60,50,pcs,18,1234,BAR001,5`}
                    download="rakhaav_product_template.csv"
                    className="inline-block mt-2 text-green-600 font-bold underline"
                  >📄 Template download करें</a>
                </div>

                <label className="flex flex-col items-center justify-center w-full h-24 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 cursor-pointer hover:border-green-500 hover:bg-green-50 transition-colors">
                  <span className="text-[13px] font-bold text-slate-600">📂 Click to choose file</span>
                  <span className="text-[11px] text-slate-400 mt-1">.xlsx, .xls, .csv supported</span>
                  <input
                    type="file"
                    accept=".csv,.xlsx,.xls"
                    disabled={importBusy}
                    className="hidden"
                    onChange={e => handleImportFileChange(e.target.files?.[0])}
                  />
                </label>

                {importBusy && (
                  <div className="mt-3 flex items-center gap-2 text-[13px] font-bold text-green-700">
                    <div className="w-4 h-4 rounded-full border-2 border-green-600 border-t-transparent animate-spin" />
                    Parsing file...
                  </div>
                )}
              </>
            ) : (
              <>
                <div className="rounded-xl bg-green-50 border border-green-200 p-3 mb-4 text-[12px]">
                  <p className="font-bold text-green-800">Preview — first 5 rows of {importPreview.total} total products</p>
                  <p className="text-green-700 mt-0.5">Confirm करें तो सभी {importPreview.total} products import होंगे।</p>
                </div>

                <div className="overflow-x-auto rounded-xl border border-slate-200 mb-4">
                  <table className="w-full text-[11px]">
                    <thead className="bg-slate-100">
                      <tr>
                        {['Name','Price','Cost','Qty','Unit','HSN','GST%'].map(h => (
                          <th key={h} className="px-2 py-2 text-left font-bold text-slate-700 whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {importPreview.preview.map((r, i) => (
                        <tr key={i} className="border-t border-slate-100">
                          <td className="px-2 py-1.5 text-slate-800 font-medium max-w-[120px] truncate">{r.name}</td>
                          <td className="px-2 py-1.5 text-slate-600">₹{r.price || 0}</td>
                          <td className="px-2 py-1.5 text-slate-600">₹{r.cost_price || 0}</td>
                          <td className="px-2 py-1.5 text-slate-600">{r.quantity || 0}</td>
                          <td className="px-2 py-1.5 text-slate-600">{r.unit}</td>
                          <td className="px-2 py-1.5 text-slate-600">{r.hsn_code}</td>
                          <td className="px-2 py-1.5 text-slate-600">{r.gst_rate}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => { setImportPreview(null); setImportFile(null); }}
                    className="flex-1 h-11 rounded-xl border-2 border-slate-200 text-[13px] font-bold text-slate-600"
                  >← Change File</button>
                  <button
                    type="button"
                    onClick={handleImportConfirm}
                    disabled={importBusy}
                    className="flex-1 h-11 rounded-xl bg-green-600 text-white text-[13px] font-bold disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {importBusy
                      ? <><div className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin"/>Importing...</>
                      : `Import ${importPreview.total} Products`}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </Layout>
  );
}